POKER ENGINE

19ucc023 - Mohit Akhouri
19ucc026 - Divyansh Rastogi
19ucc119 - Abhinav Raj Upman
19ucs024 - Hardik Satish Bhati
19ucs064 - Tapomay Singh Khatri

Steps required for running the project :

1 - Open Jupyter Notebook

2 - Go to JupyterLab page through link : [ https://hub.gke2.mybinder.org/user/ipython-ipython-in-depth-kqib69cw/lab ]

3 - Select the 'Terminal' option from the 'Other' section

4 - Create a folder named 'pokerengine' and create three python files 

5 - Write the codes for the files 'poker_engine_main_file.py' , 'CallBot.py' and 'simulate.py'

6 - Next install the packages using the 'pip' command
         pip install pypokerengine
         pip install pypokergui

7 - Lastly , open the terminal and run the command : python simulate.py 

8 - Observe the results