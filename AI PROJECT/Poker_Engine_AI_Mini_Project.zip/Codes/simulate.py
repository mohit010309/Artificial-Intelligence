# simulate.py python file
# This code will call the pypokerengine, CallBot and poker_engine_main_file
# for simulation of Limit Texas Hold'em poker

# importing required packages
from pypokerengine.api.game import start_poker, setup_config
from CallBot import CallBot
from poker_engine_main_file import poker_engine_main_file
import numpy as np

# code for computation of stack log of poker bot starts here
if __name__ == '__main__':
    poker_bot = poker_engine_main_file() # initializing object of poker_bot

    # The stack log contains the total amount in stacks of the poker bot after each game (the initial stack is 100)
    stack_log = []

    # running a loop for each round for calculation of stack amount , total rounds = 100
    for round in range(100):
        p1, p2 = poker_bot, CallBot()

        # configuration setup and registration of players for the game
        config = setup_config(max_round=5, initial_stack=100, small_blind_amount=5)
        config.register_player(name="p1", algorithm=p1)
        config.register_player(name="p2", algorithm=p2)
        # calculation of poker game result
        game_result = start_poker(config, verbose=0)

        # appending new stack values each time
        stack_log.append([player['stack'] for player in game_result['players'] if player['uuid'] == poker_bot.uuid])
        print('Avg. value in stack :', '%d' % (int(np.mean(stack_log))))