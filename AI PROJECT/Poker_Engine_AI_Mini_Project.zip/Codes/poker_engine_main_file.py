# AI PROJECT - POKER ENGINE
# poker_engine_main_file.py

# 19ucc023 = Mohit Akhouri
# 19ucc026 = Divyansh Rastogi
# 19ucc119 = Abhinav Raj Upman
# 19ucs024 = Hardik Satish Bhati
# 19ucs064 = Tapomay Singh Khatri

# importing of packages from pypokerengine starts here
from pypokerengine.engine.hand_evaluator import HandEvaluator
from pypokerengine.players import BasePokerPlayer
from pypokerengine.utils.card_utils import _pick_unused_card, _fill_community_card, gen_cards

# ALGORITHM FOR win_rate_estimation function is as follows :
# This function will estimate the ratio of winning games corresponding to the current state of the game
def win_rate_estimation(nb_simulation, nb_player, hole_card, community_card=None):
    # nb_sim = simulation variable
    # nb_player = to store the value of player
    # hole_card = to store the value of hole card
    # community_card = to store the value of community card
    if not community_card: community_card = []

    # Making lists of card objects and storing them in two variable out of a deck of cards
    community_card = gen_cards(community_card) # separating community cards from the deck
    hole_card = gen_cards(hole_card) # separating hole cards from the deck

    # to estimate the win count , perform Monte Carlo simulation
    wincount = sum([montecarlo_sim(nb_player, hole_card, community_card) for _ in range(nb_simulation)])
    wincount_modified = 1.0 * wincount / nb_simulation
    return wincount_modified

# ALGORITHM FOR montecarlo_sim function is as follows :
# This function will perform montecarlo simulation on nb_player,h_card and c_card and return the values 0 and 1
# the function will return 1 if player_score > bot_score
def montecarlo_sim(nb_player, hole_card, community_card):
    # Do a Monte Carlo simulation given the current state of the game by evaluating the hands

    # performing monte carlo simulation according to the current state of the game
    # the method applied will be evaluation of hands
    community_card = _fill_community_card(community_card, used_card=hole_card + community_card)
    unused_cards = _pick_unused_card((nb_player - 1) * 2, hole_card + community_card) # picking up unused cards

    # calculation of holes and score of bot and player
    bot_hole = [unused_cards[2 * i:2 * i + 2] for i in range(nb_player - 1)]
    bot_score = [HandEvaluator.eval_hand(hole, community_card) for hole in bot_hole]
    player_score = HandEvaluator.eval_hand(hole_card, community_card)

    # checking condition = if player_score > bot_score , return 1 else 0
    if player_score >= max(bot_score):
        return 1

    return 0

# class file for poker_engine_main_file
class poker_engine_main_file(BasePokerPlayer):

    # initializing wins and losses
    def __init__(self):
        super().__init__()
        self.wins = 0
        self.losses = 0

    # creating functions for actions taken in a game of poker
    def declare_action(self, valid_actions, hole_card, round_state):

        # hole_card = to store the value of hole card
        # round_state = variable to store round state in game of poker

        # estimation of win rate
        win_rate = win_rate_estimation(100, self.num_players, hole_card, round_state['community_card'])

        # checking the condition of 'call' state in poker
        can_call = len([item for item in valid_actions if item['action'] == 'call']) > 0

        # if condition satisfied we will calculate the call amount else assign call amount value 0
        if can_call:
            # If so, compute the amount that needs to be called
            call_amount = [item for item in valid_actions if item['action'] == 'call'][0]['amount']
        else:
            call_amount = 0

        amount = None # variable to store the amount

        # If we find that win rate is very large , then we should go for 'raise' state
        if win_rate > 0.5:
            raise_amount_options = [item for item in valid_actions if item['action'] == 'raise'][0]['amount']
            if win_rate > 0.85:
                # Raise the amount as much as possible if there is extremely likely chance to win
                action = 'raise'
                amount = raise_amount_options['max']
            elif win_rate > 0.75:
                # Raise by minimum amount if there is a likely chance to win
                action = 'raise'
                amount = raise_amount_options['min']
            else:
                # If we find there is 'chance' to win , then we should go for 'call' state
                action = 'call'
        else:
            action = 'call' if can_call and call_amount == 0 else 'fold'

        # Setting the amount variable
        if amount is None:
            items = [item for item in valid_actions if item['action'] == action]
            amount = items[0]['amount']

        return action, amount

    # receive message regarding start of poker game
    def receive_game_start_message(self, game_info):
        self.num_players = game_info['player_num']

    # receive message regarding start of round state of poker game
    def receive_round_start_message(self, round_count, hole_card, seats):
        pass

    # receive message regarding start of street state of poker game
    def receive_street_start_message(self, street, round_state):
        pass

    # receive message regarding updation of game
    def receive_game_update_message(self, action, round_state):
        pass

    # receive message regarding result of round state of poker game
    def receive_round_result_message(self, winners, hand_info, round_state):
        is_winner = self.uuid in [item['uuid'] for item in winners]
        self.wins += int(is_winner)
        self.losses += int(not is_winner)

# defining setup function for poker_engine_main_file.py
def setup_ai():
    return poker_engine_main_file()